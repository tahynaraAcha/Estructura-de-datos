#pragma once
#include "Shape.h"
class circunferencia: public Shape
{
public:
	circunferencia(void);
	~circunferencia(void);
	 int getArea() { 
         return (width * width* 3.1416); 
      }
	
};


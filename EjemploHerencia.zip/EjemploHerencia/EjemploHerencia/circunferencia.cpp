#include "StdAfx.h"
#include "circunferencia.h"


circunferencia::circunferencia(void)
{
}


circunferencia::~circunferencia(void)
{
}
